use parity_scale_codec::{MaxEncodedLen};

#[derive(MaxEncodedLen)]
struct NotEncode;

fn main() {}
