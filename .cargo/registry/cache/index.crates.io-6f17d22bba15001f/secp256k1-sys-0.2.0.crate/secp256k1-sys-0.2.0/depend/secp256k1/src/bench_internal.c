/**********************************************************************
 * Copyright (c) 2014-2015 Pieter Wuille                              *
 * Distributed under the MIT software license, see the accompanying   *
 * file COPYING or http://www.opensource.org/licenses/mit-license.php.*
 **********************************************************************/
#include <stdio.h>

#include "include/secp256k1.h"

#include "assumptions.h"
#include "util.h"
#include "hash_impl.h"
#include "num_impl.h"
#include "field_impl.h"
#include "group_impl.h"
#include "scalar_impl.h"
#include "ecmult_const_impl.h"
#include "ecmult_impl.h"
#include "bench.h"
#include "secp256k1.c"

typedef struct {
    rustsecp256k1_v0_2_0_scalar scalar_x, scalar_y;
    rustsecp256k1_v0_2_0_fe fe_x, fe_y;
    rustsecp256k1_v0_2_0_ge ge_x, ge_y;
    rustsecp256k1_v0_2_0_gej gej_x, gej_y;
    unsigned char data[64];
    int wnaf[256];
} bench_inv;

void bench_setup(void* arg) {
    bench_inv *data = (bench_inv*)arg;

    static const unsigned char init_x[32] = {
        0x02, 0x03, 0x05, 0x07, 0x0b, 0x0d, 0x11, 0x13,
        0x17, 0x1d, 0x1f, 0x25, 0x29, 0x2b, 0x2f, 0x35,
        0x3b, 0x3d, 0x43, 0x47, 0x49, 0x4f, 0x53, 0x59,
        0x61, 0x65, 0x67, 0x6b, 0x6d, 0x71, 0x7f, 0x83
    };

    static const unsigned char init_y[32] = {
        0x82, 0x83, 0x85, 0x87, 0x8b, 0x8d, 0x81, 0x83,
        0x97, 0xad, 0xaf, 0xb5, 0xb9, 0xbb, 0xbf, 0xc5,
        0xdb, 0xdd, 0xe3, 0xe7, 0xe9, 0xef, 0xf3, 0xf9,
        0x11, 0x15, 0x17, 0x1b, 0x1d, 0xb1, 0xbf, 0xd3
    };

    rustsecp256k1_v0_2_0_scalar_set_b32(&data->scalar_x, init_x, NULL);
    rustsecp256k1_v0_2_0_scalar_set_b32(&data->scalar_y, init_y, NULL);
    rustsecp256k1_v0_2_0_fe_set_b32(&data->fe_x, init_x);
    rustsecp256k1_v0_2_0_fe_set_b32(&data->fe_y, init_y);
    CHECK(rustsecp256k1_v0_2_0_ge_set_xo_var(&data->ge_x, &data->fe_x, 0));
    CHECK(rustsecp256k1_v0_2_0_ge_set_xo_var(&data->ge_y, &data->fe_y, 1));
    rustsecp256k1_v0_2_0_gej_set_ge(&data->gej_x, &data->ge_x);
    rustsecp256k1_v0_2_0_gej_set_ge(&data->gej_y, &data->ge_y);
    memcpy(data->data, init_x, 32);
    memcpy(data->data + 32, init_y, 32);
}

void bench_scalar_add(void* arg, int iters) {
    int i, j = 0;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        j += rustsecp256k1_v0_2_0_scalar_add(&data->scalar_x, &data->scalar_x, &data->scalar_y);
    }
    CHECK(j <= iters);
}

void bench_scalar_negate(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_scalar_negate(&data->scalar_x, &data->scalar_x);
    }
}

void bench_scalar_sqr(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_scalar_sqr(&data->scalar_x, &data->scalar_x);
    }
}

void bench_scalar_mul(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_scalar_mul(&data->scalar_x, &data->scalar_x, &data->scalar_y);
    }
}

#ifdef USE_ENDOMORPHISM
void bench_scalar_split(void* arg, int iters) {
    int i, j = 0;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_scalar_split_lambda(&data->scalar_x, &data->scalar_y, &data->scalar_x);
        j += rustsecp256k1_v0_2_0_scalar_add(&data->scalar_x, &data->scalar_x, &data->scalar_y);
    }
    CHECK(j <= iters);
}
#endif

void bench_scalar_inverse(void* arg, int iters) {
    int i, j = 0;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_scalar_inverse(&data->scalar_x, &data->scalar_x);
        j += rustsecp256k1_v0_2_0_scalar_add(&data->scalar_x, &data->scalar_x, &data->scalar_y);
    }
    CHECK(j <= iters);
}

void bench_scalar_inverse_var(void* arg, int iters) {
    int i, j = 0;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_scalar_inverse_var(&data->scalar_x, &data->scalar_x);
        j += rustsecp256k1_v0_2_0_scalar_add(&data->scalar_x, &data->scalar_x, &data->scalar_y);
    }
    CHECK(j <= iters);
}

void bench_field_normalize(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_fe_normalize(&data->fe_x);
    }
}

void bench_field_normalize_weak(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_fe_normalize_weak(&data->fe_x);
    }
}

void bench_field_mul(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_fe_mul(&data->fe_x, &data->fe_x, &data->fe_y);
    }
}

void bench_field_sqr(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_fe_sqr(&data->fe_x, &data->fe_x);
    }
}

void bench_field_inverse(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_fe_inv(&data->fe_x, &data->fe_x);
        rustsecp256k1_v0_2_0_fe_add(&data->fe_x, &data->fe_y);
    }
}

void bench_field_inverse_var(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_fe_inv_var(&data->fe_x, &data->fe_x);
        rustsecp256k1_v0_2_0_fe_add(&data->fe_x, &data->fe_y);
    }
}

void bench_field_sqrt(void* arg, int iters) {
    int i, j = 0;
    bench_inv *data = (bench_inv*)arg;
    rustsecp256k1_v0_2_0_fe t;

    for (i = 0; i < iters; i++) {
        t = data->fe_x;
        j += rustsecp256k1_v0_2_0_fe_sqrt(&data->fe_x, &t);
        rustsecp256k1_v0_2_0_fe_add(&data->fe_x, &data->fe_y);
    }
    CHECK(j <= iters);
}

void bench_group_double_var(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_gej_double_var(&data->gej_x, &data->gej_x, NULL);
    }
}

void bench_group_add_var(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_gej_add_var(&data->gej_x, &data->gej_x, &data->gej_y, NULL);
    }
}

void bench_group_add_affine(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_gej_add_ge(&data->gej_x, &data->gej_x, &data->ge_y);
    }
}

void bench_group_add_affine_var(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_gej_add_ge_var(&data->gej_x, &data->gej_x, &data->ge_y, NULL);
    }
}

void bench_group_jacobi_var(void* arg, int iters) {
    int i, j = 0;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        j += rustsecp256k1_v0_2_0_gej_has_quad_y_var(&data->gej_x);
    }
    CHECK(j == iters);
}

void bench_ecmult_wnaf(void* arg, int iters) {
    int i, bits = 0, overflow = 0;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        bits += rustsecp256k1_v0_2_0_ecmult_wnaf(data->wnaf, 256, &data->scalar_x, WINDOW_A);
        overflow += rustsecp256k1_v0_2_0_scalar_add(&data->scalar_x, &data->scalar_x, &data->scalar_y);
    }
    CHECK(overflow >= 0);
    CHECK(bits <= 256*iters);
}

void bench_wnaf_const(void* arg, int iters) {
    int i, bits = 0, overflow = 0;
    bench_inv *data = (bench_inv*)arg;

    for (i = 0; i < iters; i++) {
        bits += rustsecp256k1_v0_2_0_wnaf_const(data->wnaf, &data->scalar_x, WINDOW_A, 256);
        overflow += rustsecp256k1_v0_2_0_scalar_add(&data->scalar_x, &data->scalar_x, &data->scalar_y);
    }
    CHECK(overflow >= 0);
    CHECK(bits <= 256*iters);
}


void bench_sha256(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;
    rustsecp256k1_v0_2_0_sha256 sha;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_sha256_initialize(&sha);
        rustsecp256k1_v0_2_0_sha256_write(&sha, data->data, 32);
        rustsecp256k1_v0_2_0_sha256_finalize(&sha, data->data);
    }
}

void bench_hmac_sha256(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;
    rustsecp256k1_v0_2_0_hmac_sha256 hmac;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_hmac_sha256_initialize(&hmac, data->data, 32);
        rustsecp256k1_v0_2_0_hmac_sha256_write(&hmac, data->data, 32);
        rustsecp256k1_v0_2_0_hmac_sha256_finalize(&hmac, data->data);
    }
}

void bench_rfc6979_hmac_sha256(void* arg, int iters) {
    int i;
    bench_inv *data = (bench_inv*)arg;
    rustsecp256k1_v0_2_0_rfc6979_hmac_sha256 rng;

    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_rfc6979_hmac_sha256_initialize(&rng, data->data, 64);
        rustsecp256k1_v0_2_0_rfc6979_hmac_sha256_generate(&rng, data->data, 32);
    }
}

void bench_context_verify(void* arg, int iters) {
    int i;
    (void)arg;
    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_context_destroy(rustsecp256k1_v0_2_0_context_create(SECP256K1_CONTEXT_VERIFY));
    }
}

void bench_context_sign(void* arg, int iters) {
    int i;
    (void)arg;
    for (i = 0; i < iters; i++) {
        rustsecp256k1_v0_2_0_context_destroy(rustsecp256k1_v0_2_0_context_create(SECP256K1_CONTEXT_SIGN));
    }
}

#ifndef USE_NUM_NONE
void bench_num_jacobi(void* arg, int iters) {
    int i, j = 0;
    bench_inv *data = (bench_inv*)arg;
    rustsecp256k1_v0_2_0_num nx, norder;

    rustsecp256k1_v0_2_0_scalar_get_num(&nx, &data->scalar_x);
    rustsecp256k1_v0_2_0_scalar_order_get_num(&norder);
    rustsecp256k1_v0_2_0_scalar_get_num(&norder, &data->scalar_y);

    for (i = 0; i < iters; i++) {
        j += rustsecp256k1_v0_2_0_num_jacobi(&nx, &norder);
    }
    CHECK(j <= iters);
}
#endif

int main(int argc, char **argv) {
    bench_inv data;
    int iters = get_iters(20000);

    if (have_flag(argc, argv, "scalar") || have_flag(argc, argv, "add")) run_benchmark("scalar_add", bench_scalar_add, bench_setup, NULL, &data, 10, iters*100);
    if (have_flag(argc, argv, "scalar") || have_flag(argc, argv, "negate")) run_benchmark("scalar_negate", bench_scalar_negate, bench_setup, NULL, &data, 10, iters*100);
    if (have_flag(argc, argv, "scalar") || have_flag(argc, argv, "sqr")) run_benchmark("scalar_sqr", bench_scalar_sqr, bench_setup, NULL, &data, 10, iters*10);
    if (have_flag(argc, argv, "scalar") || have_flag(argc, argv, "mul")) run_benchmark("scalar_mul", bench_scalar_mul, bench_setup, NULL, &data, 10, iters*10);
#ifdef USE_ENDOMORPHISM
    if (have_flag(argc, argv, "scalar") || have_flag(argc, argv, "split")) run_benchmark("scalar_split", bench_scalar_split, bench_setup, NULL, &data, 10, iters);
#endif
    if (have_flag(argc, argv, "scalar") || have_flag(argc, argv, "inverse")) run_benchmark("scalar_inverse", bench_scalar_inverse, bench_setup, NULL, &data, 10, 2000);
    if (have_flag(argc, argv, "scalar") || have_flag(argc, argv, "inverse")) run_benchmark("scalar_inverse_var", bench_scalar_inverse_var, bench_setup, NULL, &data, 10, 2000);

    if (have_flag(argc, argv, "field") || have_flag(argc, argv, "normalize")) run_benchmark("field_normalize", bench_field_normalize, bench_setup, NULL, &data, 10, iters*100);
    if (have_flag(argc, argv, "field") || have_flag(argc, argv, "normalize")) run_benchmark("field_normalize_weak", bench_field_normalize_weak, bench_setup, NULL, &data, 10, iters*100);
    if (have_flag(argc, argv, "field") || have_flag(argc, argv, "sqr")) run_benchmark("field_sqr", bench_field_sqr, bench_setup, NULL, &data, 10, iters*10);
    if (have_flag(argc, argv, "field") || have_flag(argc, argv, "mul")) run_benchmark("field_mul", bench_field_mul, bench_setup, NULL, &data, 10, iters*10);
    if (have_flag(argc, argv, "field") || have_flag(argc, argv, "inverse")) run_benchmark("field_inverse", bench_field_inverse, bench_setup, NULL, &data, 10, iters);
    if (have_flag(argc, argv, "field") || have_flag(argc, argv, "inverse")) run_benchmark("field_inverse_var", bench_field_inverse_var, bench_setup, NULL, &data, 10, iters);
    if (have_flag(argc, argv, "field") || have_flag(argc, argv, "sqrt")) run_benchmark("field_sqrt", bench_field_sqrt, bench_setup, NULL, &data, 10, iters);

    if (have_flag(argc, argv, "group") || have_flag(argc, argv, "double")) run_benchmark("group_double_var", bench_group_double_var, bench_setup, NULL, &data, 10, iters*10);
    if (have_flag(argc, argv, "group") || have_flag(argc, argv, "add")) run_benchmark("group_add_var", bench_group_add_var, bench_setup, NULL, &data, 10, iters*10);
    if (have_flag(argc, argv, "group") || have_flag(argc, argv, "add")) run_benchmark("group_add_affine", bench_group_add_affine, bench_setup, NULL, &data, 10, iters*10);
    if (have_flag(argc, argv, "group") || have_flag(argc, argv, "add")) run_benchmark("group_add_affine_var", bench_group_add_affine_var, bench_setup, NULL, &data, 10, iters*10);
    if (have_flag(argc, argv, "group") || have_flag(argc, argv, "jacobi")) run_benchmark("group_jacobi_var", bench_group_jacobi_var, bench_setup, NULL, &data, 10, iters);

    if (have_flag(argc, argv, "ecmult") || have_flag(argc, argv, "wnaf")) run_benchmark("wnaf_const", bench_wnaf_const, bench_setup, NULL, &data, 10, iters);
    if (have_flag(argc, argv, "ecmult") || have_flag(argc, argv, "wnaf")) run_benchmark("ecmult_wnaf", bench_ecmult_wnaf, bench_setup, NULL, &data, 10, iters);

    if (have_flag(argc, argv, "hash") || have_flag(argc, argv, "sha256")) run_benchmark("hash_sha256", bench_sha256, bench_setup, NULL, &data, 10, iters);
    if (have_flag(argc, argv, "hash") || have_flag(argc, argv, "hmac")) run_benchmark("hash_hmac_sha256", bench_hmac_sha256, bench_setup, NULL, &data, 10, iters);
    if (have_flag(argc, argv, "hash") || have_flag(argc, argv, "rng6979")) run_benchmark("hash_rfc6979_hmac_sha256", bench_rfc6979_hmac_sha256, bench_setup, NULL, &data, 10, iters);

    if (have_flag(argc, argv, "context") || have_flag(argc, argv, "verify")) run_benchmark("context_verify", bench_context_verify, bench_setup, NULL, &data, 10, 1 + iters/1000);
    if (have_flag(argc, argv, "context") || have_flag(argc, argv, "sign")) run_benchmark("context_sign", bench_context_sign, bench_setup, NULL, &data, 10, 1 + iters/100);

#ifndef USE_NUM_NONE
    if (have_flag(argc, argv, "num") || have_flag(argc, argv, "jacobi")) run_benchmark("num_jacobi", bench_num_jacobi, bench_setup, NULL, &data, 10, iters*10);
#endif
    return 0;
}
