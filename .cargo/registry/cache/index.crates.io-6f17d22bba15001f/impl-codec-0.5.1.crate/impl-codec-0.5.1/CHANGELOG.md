# Changelog

The format is based on [Keep a Changelog].

[Keep a Changelog]: http://keepachangelog.com/en/1.0.0/

## [Unreleased]

## [0.5.1] - 2021-07-02
### Dependencies
- Updated `parity-scale-codec` to 2.2. [#552](https://github.com/paritytech/parity-common/pull/552)

## [0.5.0] - 2021-01-27
### Breaking
- Updated `parity-scale-codec` to 2.0. [#510](https://github.com/paritytech/parity-common/pull/510)
